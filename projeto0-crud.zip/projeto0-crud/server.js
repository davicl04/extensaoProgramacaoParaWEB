const express = require('express');
const app = express();

const port = 3000;

const db = require('./db');

const path = require('path');
app.use(express.static(path.join(__dirname, '/public')));

app.get('/', (req, res)=>{
    res.sendFile(path.join(__dirname, '/public', 'index.html'));
});

const apiRoutes = require('./routes/api');
app.use('/api/users ', apiRoutes);


app.listen(port, ()=>{
    console.log("Server up");
});