const express = require('express')
const app = express()
const port = 3000
app.use(express.urlencoded ({extended:true}));
app.use(express.static('public'));


app.get('/', (req, res) => {
    // express.Router('http://127.0.0.1:5500/projeto08052026/public/index.html');
    res.sendFile(__dirname + '/public/index.html');
})

app.get('/sobre', (req, res)=> {
    // express.Router('http://127.0.0.1:5500/projeto08052026/public/sobre.html');
    res.sendFile(__dirname + '/public/sobre.html')
}) 

app.post('/contato', (req, res) =>{
    const {nome,email} = req.body;
    res.send(`Dados cadastrados:' ${nome}, ${email}`);
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
